### Hexlet tests and linter status:
[![Actions Status](https://github.com/barcelona2004/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/barcelona2004/python-project-50/actions)
<a href="https://codeclimate.com/github/barcelona2004/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/f34c62de24c688f9a7ce/maintainability" /></a>
<a href="https://codeclimate.com/github/barcelona2004/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/f34c62de24c688f9a7ce/test_coverage" /></a>

how it works for json files - https://asciinema.org/a/rHUHZmG4zMBUmVvjTCyTU7tnf

how it works for yaml files - https://asciinema.org/a/qOyFLLXxE2cKjDxQKDrWSMV3H

how it works for big data - https://asciinema.org/a/iVZo1XCnAqCxVqiyxwp1babPl

how it works for plain format - https://asciinema.org/a/oGUPFIiqwctuVnZMMk6ht8fta